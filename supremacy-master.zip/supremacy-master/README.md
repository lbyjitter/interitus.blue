# supremacy

## this is a fork of the original supremecy that accidently got forked when i made a comment on it and I dont have anything to do with this source except it got forked / Oneshot

Supremacy Counter-Strike: Global Offensive cheat, by https://interwebz.cc/. Good for learning, everything is commented. Open Source.

Since the source has been going around awhile, and people thinking they're cool because they have this source I decieded to release it.
It's 90% a skeet paste, and the source should be good for people to learn from.

Another thing is, people were literally trying to sell this source, and sell cheats based from this. If you do that, you're basically scamming people, don't do that, thanks.

NOTE: Compile in Release x86 -- some morons need this information.

The cheat was mainly composed of getting skeet users to dump the cheat modules, and then reversing the cheat(skeet), and implementing their functions into Supremacy. The menu was designed to make esoterik mad, and ultimately ending up cracking the cheat due to lack of modern security.
